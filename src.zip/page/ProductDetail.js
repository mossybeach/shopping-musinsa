import React from "react";

const ProductDetail = () => {
  return <div>product detail</div>;
};

export default ProductDetail;
